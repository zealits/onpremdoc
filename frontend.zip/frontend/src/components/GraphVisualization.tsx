import { useEffect, useRef, useState } from 'react';
import { Box, Typography, CircularProgress, Select, MenuItem, FormControl, InputLabel, Alert } from '@mui/material';
import { useGraphStats } from '../hooks/useDocuments';
import { documentsApi } from '../api/documents';

interface GraphVisualizationProps {
  documentId: string;
}

export const GraphVisualization = ({ documentId }: GraphVisualizationProps) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [vizType, setVizType] = useState<'interactive' | 'static' | 'simplified'>('interactive');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { data: stats } = useGraphStats(documentId);

  useEffect(() => {
    const loadVisualization = async () => {
      if (!documentId) return;

      setLoading(true);
      setError(null);

      try {
        const blob = await documentsApi.getGraphVisualization(documentId, vizType);
        const url = URL.createObjectURL(blob);

        if (iframeRef.current) {
          iframeRef.current.src = url;
        }

        // Cleanup URL on unmount
        return () => URL.revokeObjectURL(url);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load visualization');
      } finally {
        setLoading(false);
      }
    };

    loadVisualization();
  }, [documentId, vizType]);

  return (
    <Box className="h-full flex flex-col">
      <Box className="flex items-center justify-between mb-4">
        <Typography variant="h6">Graph Visualization</Typography>
        <FormControl size="small" className="w-48">
          <InputLabel>Type</InputLabel>
          <Select
            value={vizType}
            onChange={(e) => setVizType(e.target.value as typeof vizType)}
            label="Type"
          >
            <MenuItem value="interactive">Interactive</MenuItem>
            <MenuItem value="static">Static</MenuItem>
            <MenuItem value="simplified">Simplified</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {stats && (
        <Box className="mb-4 p-3 bg-gray-50 dark:bg-gray-800 rounded">
          <Typography variant="caption" className="text-gray-600">
            Nodes: {stats.total_nodes} | Edges: {stats.total_edges} | Density: {stats.density.toFixed(3)}
          </Typography>
        </Box>
      )}

      {loading && (
        <Box className="flex justify-center items-center h-64">
          <CircularProgress />
        </Box>
      )}

      {error && (
        <Alert severity="error" className="mb-4">
          {error}
        </Alert>
      )}

      <Box className="flex-1 border rounded overflow-hidden">
        <iframe
          ref={iframeRef}
          className="w-full h-full"
          title="Graph Visualization"
        />
      </Box>
    </Box>
  );
};
