import { Box, Typography, Card, CardContent, Chip } from '@mui/material';
import { TrendingUp, FileText } from 'lucide-react';
import type { ChunkDetail } from '../api/types';

interface ChunkAnalysisProps {
  chunkAnalysis?: string | null;
  chunks: ChunkDetail[];
  onChunkClick?: (chunkIndex: number) => void;
}

export const ChunkAnalysis = ({ chunkAnalysis, chunks, onChunkClick }: ChunkAnalysisProps) => {
  // Filter and sort chunks: only seed and second_seed, sorted by similarity_score
  const relevantChunks = chunks
    .filter(
      (chunk) =>
        chunk.retrieval_source === 'seed' || chunk.retrieval_source === 'second_seed'
    )
    .sort((a, b) => {
      // Sort by similarity_score (descending), nulls last
      if (a.similarity_score === null && b.similarity_score === null) return 0;
      if (a.similarity_score === null) return 1;
      if (b.similarity_score === null) return -1;
      return b.similarity_score - a.similarity_score;
    });

  if (!chunkAnalysis && relevantChunks.length === 0) {
    return null;
  }

  return (
    <Box className="space-y-4 mt-4">
      {/* Chunk Analysis Text */}
      {chunkAnalysis && (
        <Card className="bg-[#2a2a2a] border border-gray-700">
          <CardContent className="p-4">
            <Typography variant="subtitle2" className="font-semibold mb-2 flex items-center gap-2 text-gray-100">
              <TrendingUp className="w-4 h-4" />
              Analysis
            </Typography>
            <Typography variant="body2" className="whitespace-pre-wrap text-gray-300">
              {chunkAnalysis}
            </Typography>
          </CardContent>
        </Card>
      )}

      {/* Ranked Chunks */}
      {relevantChunks.length > 0 && (
        <Box>
          <Typography variant="subtitle2" className="font-semibold mb-3 flex items-center gap-2 text-gray-100">
            <FileText className="w-4 h-4" />
            Top Chunks (by Similarity)
          </Typography>
          <Box className="space-y-2">
            {relevantChunks.map((chunk, index) => (
              <Card
                key={chunk.chunk_index}
                className={`cursor-pointer hover:shadow-md transition-shadow border ${
                  chunk.retrieval_source === 'seed'
                    ? 'border-yellow-600 bg-yellow-900/20'
                    : 'border-green-600 bg-green-900/20'
                }`}
                onClick={() => onChunkClick?.(chunk.chunk_index)}
              >
                <CardContent className="p-3">
                  <Box className="flex items-start justify-between mb-2">
                    <Box className="flex items-center gap-2">
                      <Typography
                        variant="caption"
                        className="font-mono text-xs bg-[#1a1a1a] px-2 py-1 rounded border border-gray-700 text-gray-300"
                      >
                        #{index + 1}
                      </Typography>
                      <Chip
                        label={`Chunk ${chunk.chunk_index}`}
                        size="small"
                        className="font-mono text-xs bg-[#1a1a1a] text-gray-300"
                      />
                      <Chip
                        label={chunk.retrieval_source === 'seed' ? 'Seed' : 'Second Seed'}
                        size="small"
                        color={chunk.retrieval_source === 'seed' ? 'warning' : 'success'}
                        className="text-xs"
                      />
                    </Box>
                    {chunk.similarity_score !== null && chunk.similarity_score !== undefined && (
                      <Typography variant="caption" className="text-gray-300 font-semibold">
                        {(chunk.similarity_score * 100).toFixed(1)}%
                      </Typography>
                    )}
                  </Box>
                  {chunk.heading && (
                    <Typography variant="subtitle2" className="font-semibold mb-1 text-sm text-gray-100">
                      {chunk.heading}
                    </Typography>
                  )}
                  {chunk.summary && (
                    <Typography variant="body2" className="text-gray-400 text-xs line-clamp-2">
                      {chunk.summary}
                    </Typography>
                  )}
                  {chunk.section_path && (
                    <Typography variant="caption" className="text-gray-500 text-xs mt-1 block">
                      {chunk.section_path}
                    </Typography>
                  )}
                </CardContent>
              </Card>
            ))}
          </Box>
        </Box>
      )}
    </Box>
  );
};
