import { Card, CardContent, Typography, Box, Chip } from '@mui/material';
import { FileText, MapPin } from 'lucide-react';
import type { ChunkDetail } from '../api/types';

interface ChunkCardProps {
  chunk: ChunkDetail;
  onClick?: () => void;
}

export const ChunkCard = ({ chunk, onClick }: ChunkCardProps) => {
  const getSourceColor = (source: ChunkDetail['retrieval_source']) => {
    switch (source) {
      case 'seed':
        return 'warning';
      case 'graph_expanded':
        return 'info';
      case 'second_seed':
        return 'success';
      case 'second_expanded':
        return 'success';
      default:
        return 'default';
    }
  };

  return (
    <Card
      className={`cursor-pointer hover:shadow-md transition-shadow ${onClick ? '' : ''}`}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <Box className="flex items-start justify-between mb-2">
          <Box className="flex items-center gap-2">
            <Typography variant="subtitle2" className="font-semibold">
              {chunk.heading || 'No Heading'}
            </Typography>
            <Chip
              label={chunk.retrieval_source.replace('_', ' ')}
              color={getSourceColor(chunk.retrieval_source)}
              size="small"
            />
          </Box>
          {chunk.similarity_score && (
            <Chip
              label={`${(chunk.similarity_score * 100).toFixed(0)}%`}
              size="small"
              variant="outlined"
            />
          )}
        </Box>

        <Typography variant="body2" className="text-gray-600 mb-3 line-clamp-3">
          {chunk.summary || chunk.content.substring(0, 200)}
        </Typography>

        <Box className="flex items-center gap-4 text-xs text-gray-500">
          {chunk.section_path && (
            <Box className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span>{chunk.section_path}</span>
            </Box>
          )}
          {chunk.page_number && (
            <Box className="flex items-center gap-1">
              <FileText className="w-3 h-3" />
              <span>Page {chunk.page_number}</span>
            </Box>
          )}
          {chunk.start_line && <span>Line {chunk.start_line}</span>}
        </Box>
      </CardContent>
    </Card>
  );
};
