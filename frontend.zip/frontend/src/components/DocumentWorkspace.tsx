import { useState } from 'react';
import { Box, IconButton, Typography, Button, CircularProgress, Alert } from '@mui/material';
import { ArrowLeft, Sparkles, Network } from 'lucide-react';
import { SourcesPanel } from './SourcesPanel';
import { ChatPanel } from './ChatPanel';
import { StudioPanel } from './StudioPanel';
import { useDocument, useVectorizeDocument } from '../hooks/useDocuments';
import type { ChunkDetail } from '../api/types';

interface DocumentWorkspaceProps {
  documentId: string;
  onBack: () => void;
}

export const DocumentWorkspace = ({ documentId, onBack }: DocumentWorkspaceProps) => {
  const [selectedChunkIndex, setSelectedChunkIndex] = useState<number | null>(null);
  const [chunks, setChunks] = useState<ChunkDetail[]>([]);
  const { data: document } = useDocument(documentId);
  const vectorizeMutation = useVectorizeDocument();

  const handleChunkClick = (chunkIndex: number) => {
    setSelectedChunkIndex(chunkIndex);
  };

  const handleChunksUpdate = (newChunks: ChunkDetail[]) => {
    setChunks(newChunks);
  };

  const handleVectorize = async () => {
    try {
      await vectorizeMutation.mutateAsync(documentId);
    } catch (error) {
      console.error('Vectorization failed:', error);
    }
  };

  // Check document status
  const hasMarkdown = document?.markdown_path !== null && document?.markdown_path !== undefined;
  const isVectorized = document?.vector_mapping_path !== null && document?.vector_mapping_path !== undefined;
  const isReady = document?.status === 'ready';

  return (
    <Box className="h-screen flex flex-col bg-[#1a1a1a]">
      {/* Header */}
      <Box className="flex items-center gap-4 p-4 border-b border-gray-700 bg-[#2a2a2a]">
        <IconButton onClick={onBack} size="small" className="hover:bg-gray-700 text-gray-300">
          <ArrowLeft className="w-5 h-5" />
        </IconButton>
        <Typography variant="h6" className="font-semibold flex-1 text-gray-100">
          Document Workspace
        </Typography>
      </Box>

      {/* Three-Column Layout */}
      <Box className="flex-1 flex overflow-hidden">
        {/* Left Panel - Sources */}
        <Box className="w-1/3 border-r border-gray-700 flex flex-col overflow-hidden">
          <Box className="px-4 py-2 border-b border-gray-700 bg-[#2a2a2a]">
            <Typography variant="subtitle2" className="font-semibold text-gray-300">
              Sources
            </Typography>
          </Box>
          <Box className="flex-1 overflow-hidden">
            <SourcesPanel
              documentId={documentId}
              chunks={chunks}
              selectedChunkIndex={selectedChunkIndex}
            />
          </Box>
        </Box>

        {/* Middle Panel - Chat */}
        <Box className="w-1/3 border-r border-gray-700 flex flex-col overflow-hidden">
          <Box className="px-4 py-2 border-b border-gray-700 bg-[#2a2a2a]">
            <Typography variant="subtitle2" className="font-semibold text-gray-300">
              Chat
            </Typography>
          </Box>
          <Box className="flex-1 overflow-hidden">
            <ChatPanel
              documentId={documentId}
              onChunkClick={handleChunkClick}
              onChunksUpdate={handleChunksUpdate}
            />
          </Box>
        </Box>

        {/* Right Panel - Studio */}
        <Box className="w-1/3 flex flex-col overflow-hidden">
          <Box className="px-4 py-2 border-b border-gray-700 bg-[#2a2a2a]">
            <Typography variant="subtitle2" className="font-semibold text-gray-300">
              Studio
            </Typography>
          </Box>
          <Box className="flex-1 overflow-hidden">
            <StudioPanel documentId={documentId} />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};
