import { useEffect, useRef, useState } from 'react';
import { Box, Typography, CircularProgress } from '@mui/material';
import { useMarkdown } from '../hooks/useDocuments';
import { calculateHighlightRanges } from '../utils/highlighting';
import { renderMarkdownWithHighlights } from '../utils/markdown';
import { marked } from 'marked';
import type { ChunkDetail } from '../api/types';

interface MarkdownViewerProps {
  documentId: string;
  chunks: ChunkDetail[];
  selectedChunkIndex?: number;
}

export const MarkdownViewer = ({ documentId, chunks, selectedChunkIndex }: MarkdownViewerProps) => {
  const { data: markdown, isLoading } = useMarkdown(documentId);
  const viewerRef = useRef<HTMLDivElement>(null);
  const [highlightedHtml, setHighlightedHtml] = useState<string>('');

  useEffect(() => {
    const renderMarkdown = async () => {
      if (!markdown) return;

      if (!chunks.length) {
        // Render markdown without highlights
        try {
          const html = await marked.parse(markdown);
          setHighlightedHtml(html);
        } catch (err) {
          console.error('Error parsing markdown:', err);
        }
        return;
      }

      const highlights = calculateHighlightRanges(chunks);
      const highlightedMarkdown = renderMarkdownWithHighlights(markdown, highlights);

      // Convert to HTML
      try {
        const html = await marked.parse(highlightedMarkdown);
        setHighlightedHtml(html);
      } catch (err) {
        console.error('Error parsing highlighted markdown:', err);
      }
    };

    renderMarkdown();
  }, [markdown, chunks]);

  useEffect(() => {
    if (selectedChunkIndex !== undefined && viewerRef.current) {
      const element = viewerRef.current.querySelector(
        `[data-chunk-index="${selectedChunkIndex}"]`
      );
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        // Add temporary highlight
        element.classList.add('ring-2', 'ring-blue-500');
        setTimeout(() => {
          element.classList.remove('ring-2', 'ring-blue-500');
        }, 2000);
      }
    }
  }, [selectedChunkIndex]);

  if (isLoading) {
    return (
      <Box className="flex justify-center items-center p-8">
        <CircularProgress />
      </Box>
    );
  }

  if (!markdown) {
    return (
      <Box className="p-4 text-gray-500">
        Markdown content not available
      </Box>
    );
  }

  return (
    <Box className="h-full overflow-auto relative">
      <Box
        ref={viewerRef}
        className="prose prose-sm max-w-none dark:prose-invert p-6"
        dangerouslySetInnerHTML={{ __html: highlightedHtml }}
      />

      {/* Highlight Legend */}
      <Box className="fixed bottom-4 right-4 bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg border">
        <Typography variant="caption" className="font-semibold mb-2 block">
          Highlight Legend
        </Typography>
        <Box className="space-y-1 text-xs">
          <Box className="flex items-center gap-2">
            <Box className="w-4 h-4 bg-yellow-300 rounded" />
            <span>Seed (Direct Match)</span>
          </Box>
          <Box className="flex items-center gap-2">
            <Box className="w-4 h-4 bg-blue-200 rounded" />
            <span>Graph Expanded</span>
          </Box>
          <Box className="flex items-center gap-2">
            <Box className="w-4 h-4 bg-green-200 rounded" />
            <span>Second Search</span>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};
