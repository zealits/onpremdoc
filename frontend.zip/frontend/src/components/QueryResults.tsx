import { Box, Typography, Card, CardContent, Chip, Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
import { ExpandMore } from '@mui/icons-material';
import { TrendingUp, FileText } from 'lucide-react';
import type { QueryResponse, ChunkDetail } from '../api/types';
import { ChunkCard } from './ChunkCard';

interface QueryResultsProps {
  results: QueryResponse | null;
  onChunkSelect?: (chunk: ChunkDetail) => void;
}

export const QueryResults = ({ results, onChunkSelect }: QueryResultsProps) => {
  if (!results) return null;

  return (
    <Box className="space-y-6">
      {/* Answer Section */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20">
        <CardContent className="p-6">
          <Typography variant="h6" className="mb-3 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Answer
          </Typography>
          <Typography variant="body1" className="whitespace-pre-wrap">
            {results.answer}
          </Typography>
        </CardContent>
      </Card>

      {/* Retrieval Stats */}
      <Card>
        <CardContent>
          <Typography variant="h6" className="mb-3">
            Retrieval Statistics
          </Typography>
          <Box className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Box>
              <Typography variant="caption" className="text-gray-500">
                Seed Chunks
              </Typography>
              <Typography variant="h6">{results.retrieval_stats.seed_chunks}</Typography>
            </Box>
            <Box>
              <Typography variant="caption" className="text-gray-500">
                Graph Expanded
              </Typography>
              <Typography variant="h6">{results.retrieval_stats.graph_expanded_chunks}</Typography>
            </Box>
            <Box>
              <Typography variant="caption" className="text-gray-500">
                Total Chunks
              </Typography>
              <Typography variant="h6">{results.retrieval_stats.total_chunks_used}</Typography>
            </Box>
            <Box>
              <Typography variant="caption" className="text-gray-500">
                Iterations
              </Typography>
              <Typography variant="h6">{results.retrieval_stats.iterations}</Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Chunks Section */}
      <Box>
        <Typography variant="h6" className="mb-4 flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Retrieved Chunks ({results.chunks.length})
        </Typography>
        <Box className="space-y-3">
          {results.chunks.map((chunk) => (
            <ChunkCard
              key={chunk.chunk_index}
              chunk={chunk}
              onClick={() => onChunkSelect?.(chunk)}
            />
          ))}
        </Box>
      </Box>

      {/* Chunk Analysis (if available) */}
      {results.chunk_analysis && (
        <Accordion>
          <AccordionSummary expandIcon={<ExpandMore />}>
            <Typography variant="subtitle2">Chunk Analysis</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body2" className="whitespace-pre-wrap text-gray-600">
              {results.chunk_analysis}
            </Typography>
          </AccordionDetails>
        </Accordion>
      )}
    </Box>
  );
};
