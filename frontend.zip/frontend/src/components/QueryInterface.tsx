import { useState } from 'react';
import { useDocumentQuery } from '../hooks/useQuery';
import { Button, TextField, Box, CircularProgress } from '@mui/material';
import { Send, Search } from 'lucide-react';

interface QueryInterfaceProps {
  documentId: string;
  onQuerySuccess: (query: string) => void;
}

export const QueryInterface = ({ documentId, onQuerySuccess }: QueryInterfaceProps) => {
  const [query, setQuery] = useState('');
  const queryMutation = useDocumentQuery();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || !documentId) return;

    try {
      await queryMutation.mutateAsync({
        query: query.trim(),
        document_id: documentId,
        include_chunks: true,
      });
      onQuerySuccess(query);
    } catch (error) {
      console.error('Query failed:', error);
    }
  };

  return (
    <Box className="w-full">
      <form onSubmit={handleSubmit} className="flex gap-2">
        <TextField
          fullWidth
          placeholder="Ask a question about the document..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          disabled={queryMutation.isPending}
          variant="outlined"
          size="medium"
          InputProps={{
            startAdornment: (
              <Box className="mr-2">
                <Search className="w-5 h-5 text-gray-400" />
              </Box>
            ),
          }}
        />
        <Button
          type="submit"
          variant="contained"
          disabled={!query.trim() || queryMutation.isPending}
          startIcon={
            queryMutation.isPending ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              <Send className="w-5 h-5" />
            )
          }
        >
          {queryMutation.isPending ? 'Searching...' : 'Search'}
        </Button>
      </form>
    </Box>
  );
};
