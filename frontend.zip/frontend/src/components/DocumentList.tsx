import { useDocuments } from '../hooks/useDocuments';
import { StatusBadge } from './StatusBadge';
import { Card, CardContent, Typography, Box, CircularProgress } from '@mui/material';
import { FileText } from 'lucide-react';

interface DocumentListProps {
  onSelectDocument: (documentId: string) => void;
}

export const DocumentList = ({ onSelectDocument }: DocumentListProps) => {
  const { data: documents, isLoading, error } = useDocuments();

  if (isLoading) {
    return (
      <Box className="flex justify-center items-center p-8">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box className="p-4 text-red-500">
        Error loading documents: {(error as Error).message}
      </Box>
    );
  }

  if (!documents || documents.length === 0) {
    return (
      <Box className="text-center p-8 text-gray-500">
        <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
        <Typography>No documents uploaded yet</Typography>
      </Box>
    );
  }

  return (
    <Box className="space-y-4">
      {documents.map((doc) => (
        <Card
          key={doc.document_id}
          className="cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => onSelectDocument(doc.document_id)}
        >
          <CardContent>
            <Box className="flex items-start justify-between">
              <Box className="flex-1">
                <Typography variant="h6" className="mb-2">
                  {doc.name}
                </Typography>
                <Box className="flex items-center gap-4 text-sm text-gray-500">
                  {doc.total_pages && <span>{doc.total_pages} pages</span>}
                  {doc.total_chunks && <span>{doc.total_chunks} chunks</span>}
                </Box>
              </Box>
              <StatusBadge status={doc.status} />
            </Box>
          </CardContent>
        </Card>
      ))}
    </Box>
  );
};
