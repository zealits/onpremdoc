import { useState, useEffect, useRef } from 'react';
import { Box, Tabs, Tab, Typography, CircularProgress, Card, CardContent, Grid, Button } from '@mui/material';
import { Network, BarChart3, Sparkles } from 'lucide-react';
import { useGraphStats, useDocument } from '../hooks/useDocuments';
import { documentsApi } from '../api/documents';
import type { GraphStats } from '../api/types';

interface StudioPanelProps {
  documentId: string;
}

export const StudioPanel = ({ documentId }: StudioPanelProps) => {
  const [activeTab, setActiveTab] = useState(0);
  const [graphHtml, setGraphHtml] = useState<string | null>(null);
  const [loadingGraph, setLoadingGraph] = useState(false);
  const [graphError, setGraphError] = useState<string | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { data: stats, isLoading: statsLoading } = useGraphStats(documentId);
  const { data: document } = useDocument(documentId);

  // Check if document is vectorized
  const isVectorized = document?.graph_path !== null && document?.graph_path !== undefined;

  // Generate graph when button is clicked
  const handleGenerateGraph = async () => {
    if (!isVectorized) return;
    
    setLoadingGraph(true);
    setGraphError(null);
    setGraphHtml(null);
    
    try {
      const blob = await documentsApi.getGraphVisualization(documentId, 'interactive');
      const html = await blob.text();
      setGraphHtml(html);
    } catch (error) {
      console.error('Failed to load graph:', error);
      setGraphError(error instanceof Error ? error.message : 'Failed to load graph');
    } finally {
      setLoadingGraph(false);
    }
  };

  return (
    <Box className="h-full flex flex-col bg-[#1a1a1a]">
      {/* Tabs */}
      <Box className="border-b border-gray-700">
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          className="min-h-[48px]"
        >
          <Tab
            icon={<Network className="w-4 h-4" />}
            label="Graph Visualization"
            iconPosition="start"
            className="min-h-[48px]"
          />
          <Tab
            icon={<BarChart3 className="w-4 h-4" />}
            label="Graph Stats"
            iconPosition="start"
            className="min-h-[48px]"
          />
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box className="flex-1 overflow-auto">
        {activeTab === 0 && (
          <Box className="h-full">
            {loadingGraph ? (
              <Box className="flex flex-col justify-center items-center h-full bg-[#1a1a1a]">
                <CircularProgress size={40} className="mb-4" />
                <Typography variant="h6" className="mb-2 text-gray-100">
                  Generating Graph
                </Typography>
                <Typography variant="body2" className="text-gray-400">
                  Creating interactive visualization...
                </Typography>
              </Box>
            ) : graphHtml ? (
              <iframe
                ref={iframeRef}
                srcDoc={graphHtml}
                className="w-full h-full border-0"
                title="Graph Visualization"
              />
            ) : (
              <Box className="flex flex-col items-center justify-center h-full p-6 text-center bg-[#1a1a1a]">
                {!isVectorized ? (
                  <>
                    <Network className="w-16 h-16 mb-4 opacity-50 text-gray-500" />
                    <Typography variant="body1" className="mb-2 text-gray-300">
                      Graph visualization not available
                    </Typography>
                    <Typography variant="body2" className="text-gray-500 mb-6">
                      Please vectorize the document first
                    </Typography>
                  </>
                ) : (
                  <>
                    <Network className="w-16 h-16 mb-4 text-blue-400" />
                    <Typography variant="body1" className="mb-2 text-gray-300">
                      Generate Graph Visualization
                    </Typography>
                    <Typography variant="body2" className="text-gray-400 mb-6 max-w-md">
                      Click the button below to generate an interactive graph visualization of the document structure.
                    </Typography>
                    <Button
                      variant="contained"
                      onClick={handleGenerateGraph}
                      disabled={loadingGraph}
                      startIcon={<Sparkles className="w-5 h-5" />}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Generate Graph
                    </Button>
                    {graphError && (
                      <Typography variant="body2" className="text-red-400 mt-4">
                        {graphError}
                      </Typography>
                    )}
                  </>
                )}
              </Box>
            )}
          </Box>
        )}

        {activeTab === 1 && (
          <Box className="p-4">
            {statsLoading ? (
              <Box className="flex justify-center items-center h-full">
                <CircularProgress />
              </Box>
            ) : stats ? (
              <Box className="space-y-4">
                {/* Overview Stats */}
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Card className="bg-[#2a2a2a]">
                      <CardContent>
                        <Typography variant="caption" className="text-gray-400">
                          Total Nodes
                        </Typography>
                        <Typography variant="h5" className="font-semibold text-gray-100">
                          {stats.total_nodes}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item xs={6}>
                    <Card className="bg-[#2a2a2a]">
                      <CardContent>
                        <Typography variant="caption" className="text-gray-400">
                          Total Edges
                        </Typography>
                        <Typography variant="h5" className="font-semibold text-gray-100">
                          {stats.total_edges}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                  <Grid item xs={6}>
                    <Card className="bg-[#2a2a2a]">
                      <CardContent>
                        <Typography variant="caption" className="text-gray-400">
                          Graph Density
                        </Typography>
                        <Typography variant="h5" className="font-semibold text-gray-100">
                          {stats.density.toFixed(4)}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>

                {/* Node Types */}
                {Object.keys(stats.node_types).length > 0 && (
                  <Card className="bg-[#2a2a2a]">
                    <CardContent>
                      <Typography variant="subtitle1" className="font-semibold mb-3 text-gray-100">
                        Node Types
                      </Typography>
                      <Box className="space-y-2">
                        {Object.entries(stats.node_types).map(([type, count]) => (
                          <Box key={type} className="flex justify-between items-center">
                            <Typography variant="body2" className="capitalize text-gray-300">
                              {type.replace(/_/g, ' ')}
                            </Typography>
                            <Typography variant="body2" className="font-semibold text-gray-100">
                              {count}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    </CardContent>
                  </Card>
                )}

                {/* Edge Relations */}
                {Object.keys(stats.edge_relations).length > 0 && (
                  <Card className="bg-[#2a2a2a]">
                    <CardContent>
                      <Typography variant="subtitle1" className="font-semibold mb-3 text-gray-100">
                        Edge Relations
                      </Typography>
                      <Box className="space-y-2">
                        {Object.entries(stats.edge_relations).map(([relation, count]) => (
                          <Box key={relation} className="flex justify-between items-center">
                            <Typography variant="body2" className="capitalize text-gray-300">
                              {relation.replace(/_/g, ' ')}
                            </Typography>
                            <Typography variant="body2" className="font-semibold text-gray-100">
                              {count}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    </CardContent>
                  </Card>
                )}

                {/* Similarity Stats */}
                {stats.similarity_stats && (
                  <Card className="bg-[#2a2a2a]">
                    <CardContent>
                      <Typography variant="subtitle1" className="font-semibold mb-3 text-gray-100">
                        Similarity Statistics
                      </Typography>
                      <Grid container spacing={2}>
                        <Grid item xs={6}>
                          <Typography variant="caption" className="text-gray-400">
                            Count
                          </Typography>
                          <Typography variant="body1" className="font-semibold text-gray-100">
                            {stats.similarity_stats.count}
                          </Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="caption" className="text-gray-400">
                            Average
                          </Typography>
                          <Typography variant="body1" className="font-semibold text-gray-100">
                            {stats.similarity_stats.average.toFixed(4)}
                          </Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="caption" className="text-gray-400">
                            Min
                          </Typography>
                          <Typography variant="body1" className="font-semibold text-gray-100">
                            {stats.similarity_stats.min.toFixed(4)}
                          </Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="caption" className="text-gray-400">
                            Max
                          </Typography>
                          <Typography variant="body1" className="font-semibold text-gray-100">
                            {stats.similarity_stats.max.toFixed(4)}
                          </Typography>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                )}
              </Box>
            ) : (
              <Box className="flex flex-col items-center justify-center h-full p-6 text-center text-gray-400">
                <BarChart3 className="w-16 h-16 mb-4 opacity-50" />
                <Typography variant="body1" className="mb-2 text-gray-300">
                  Graph statistics not available
                </Typography>
                <Typography variant="body2" className="text-gray-500">
                  Please vectorize the document first
                </Typography>
              </Box>
            )}
          </Box>
        )}
      </Box>
    </Box>
  );
};
