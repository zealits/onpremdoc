import { useState } from 'react';
import { usePageSummary } from '../hooks/useDocuments';
import { Box, Typography, Card, CardContent, Button, CircularProgress, Chip } from '@mui/material';
import { ChevronLeft, ChevronRight } from '@mui/icons-material';

interface PageNavigatorProps {
  documentId: string;
  totalPages?: number | null;
}

export const PageNavigator = ({ documentId, totalPages }: PageNavigatorProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const { data: summary, isLoading } = usePageSummary(documentId, currentPage);

  const handlePrev = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (totalPages && currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <Box className="space-y-4">
      <Box className="flex items-center justify-between">
        <Typography variant="h6">Page Summary</Typography>
        <Box className="flex items-center gap-2">
          <Button
            variant="outlined"
            size="small"
            onClick={handlePrev}
            disabled={currentPage <= 1}
            startIcon={<ChevronLeft />}
          >
            Prev
          </Button>
          <Typography variant="body2" className="px-4">
            Page {currentPage} {totalPages ? `of ${totalPages}` : ''}
          </Typography>
          <Button
            variant="outlined"
            size="small"
            onClick={handleNext}
            disabled={totalPages ? currentPage >= totalPages : false}
            endIcon={<ChevronRight />}
          >
            Next
          </Button>
        </Box>
      </Box>

      {isLoading ? (
        <Box className="flex justify-center p-8">
          <CircularProgress />
        </Box>
      ) : summary ? (
        <Card>
          <CardContent>
            {summary.page_classification && (
              <Chip label={summary.page_classification} size="small" className="mb-3" />
            )}

            <Typography variant="h6" className="mb-3">
              Summary
            </Typography>
            <Typography variant="body1" className="mb-4 whitespace-pre-wrap">
              {summary.summary}
            </Typography>

            {summary.key_points.length > 0 && (
              <Box className="mb-4">
                <Typography variant="subtitle2" className="mb-2 font-semibold">
                  Key Points
                </Typography>
                <ul className="list-disc list-inside space-y-1">
                  {summary.key_points.map((point, idx) => (
                    <li key={idx} className="text-sm">
                      {point}
                    </li>
                  ))}
                </ul>
              </Box>
            )}

            {summary.sections.length > 0 && (
              <Box>
                <Typography variant="subtitle2" className="mb-2 font-semibold">
                  Sections
                </Typography>
                <Box className="flex flex-wrap gap-2">
                  {summary.sections.map((section, idx) => (
                    <Chip key={idx} label={section} size="small" variant="outlined" />
                  ))}
                </Box>
              </Box>
            )}

            {summary.used_adjacent_pages && (
              <Box className="mt-4 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded">
                <Typography variant="caption" className="text-yellow-800 dark:text-yellow-200">
                  Used adjacent pages: {summary.adjacent_pages_used?.join(', ')}
                </Typography>
              </Box>
            )}
          </CardContent>
        </Card>
      ) : (
        <Box className="p-4 text-gray-500 text-center">
          No summary available for this page
        </Box>
      )}
    </Box>
  );
};
