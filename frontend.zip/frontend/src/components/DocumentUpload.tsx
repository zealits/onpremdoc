import { useState, useCallback } from 'react';
import { useUploadDocument } from '../hooks/useDocuments';
import { CloudUpload, FileText } from 'lucide-react';
import { Button, Box, Typography, LinearProgress, Alert } from '@mui/material';

export const DocumentUpload = () => {
  const [dragActive, setDragActive] = useState(false);
  const uploadMutation = useUploadDocument();

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);

      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        const file = e.dataTransfer.files[0];
        if (file.type === 'application/pdf') {
          await handleFile(file);
        }
      }
    },
    []
  );

  const handleFileInput = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
        await handleFile(e.target.files[0]);
      }
    },
    []
  );

  const handleFile = async (file: File) => {
    try {
      // Upload (processing happens automatically in background)
      await uploadMutation.mutateAsync(file);
    } catch (error) {
      console.error('Upload failed:', error);
    }
  };

  return (
    <Box className="w-full max-w-2xl mx-auto p-6">
      <Typography variant="h5" className="mb-4 font-bold">
        Upload PDF Document
      </Typography>

      <Box
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-lg p-12 text-center
          transition-colors cursor-pointer
          ${
            dragActive
              ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
              : 'border-gray-300 dark:border-gray-600 hover:border-gray-400'
          }
        `}
      >
        <input
          type="file"
          accept=".pdf"
          onChange={handleFileInput}
          className="hidden"
          id="pdf-upload"
          disabled={uploadMutation.isPending}
        />
        <label htmlFor="pdf-upload" className="cursor-pointer">
          <CloudUpload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <Typography variant="h6" className="mb-2">
            Drop your PDF here or click to browse
          </Typography>
          <Typography variant="body2" className="text-gray-500">
            Only PDF files are supported
          </Typography>
        </label>
      </Box>

      {uploadMutation.isPending && (
        <Box className="mt-4">
          <LinearProgress />
          <Typography variant="body2" className="mt-2 text-center">
            Uploading...
          </Typography>
        </Box>
      )}

      {uploadMutation.isError && (
        <Alert severity="error" className="mt-4">
          Upload failed. Please try again.
        </Alert>
      )}

      {uploadMutation.isSuccess && (
        <Alert severity="success" className="mt-4">
          Document uploaded! Processing started...
        </Alert>
      )}
    </Box>
  );
};
