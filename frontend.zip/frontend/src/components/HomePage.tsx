import { useState, useCallback } from 'react';
import { useDocuments, useUploadDocument, useVectorizeDocument } from '../hooks/useDocuments';
import { Box, Typography, CircularProgress, Button, Card, CardContent } from '@mui/material';
import { CloudUpload, FileText, CheckCircle, Sparkles } from 'lucide-react';
import type { DocumentInfo } from '../api/types';

interface HomePageProps {
  onSelectDocument: (documentId: string) => void;
  onUploadClick: () => void;
}

export const HomePage = ({ onSelectDocument, onUploadClick }: HomePageProps) => {
  const { data: documents, isLoading, error } = useDocuments();
  const uploadMutation = useUploadDocument();
  const [dragActive, setDragActive] = useState(false);
  const vectorizeMutation = useVectorizeDocument();

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);

      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        const file = e.dataTransfer.files[0];
        if (file.type === 'application/pdf') {
          try {
            await uploadMutation.mutateAsync(file);
          } catch (error) {
            console.error('Upload failed:', error);
          }
        }
      }
    },
    [uploadMutation]
  );

  const handleFileInput = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
        try {
          await uploadMutation.mutateAsync(e.target.files[0]);
        } catch (error) {
          console.error('Upload failed:', error);
        }
      }
    },
    [uploadMutation]
  );

  const getStatusIndicators = (doc: DocumentInfo) => {
    const hasMarkdown = doc.markdown_path !== null && doc.markdown_path !== undefined;
    const hasVectorized = doc.vector_mapping_path !== null && doc.vector_mapping_path !== undefined;
    const isReady = doc.status === 'ready';

    return { hasMarkdown, hasVectorized, isReady };
  };

  if (isLoading) {
    return (
      <Box className="flex justify-center items-center h-full">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box className="p-4 text-red-500">
        Error loading documents: {(error as Error).message}
      </Box>
    );
  }

  return (
    <Box className="h-full flex flex-col bg-[#1a1a1a]">
      {/* Header */}
      <Box className="flex justify-between items-center p-6 border-b border-gray-700">
        <Typography variant="h5" className="font-semibold text-gray-100">
          Documents
        </Typography>
        <Button
          variant="contained"
          startIcon={<CloudUpload className="w-5 h-5" />}
          onClick={onUploadClick}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Upload PDF
        </Button>
      </Box>

      {/* Document List */}
      <Box
        className="flex-1 overflow-auto p-6"
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
      >
        {!documents || documents.length === 0 ? (
          <Box className="text-center py-16">
            <FileText className="w-20 h-20 mx-auto mb-4 text-gray-600" />
            <Typography variant="h6" className="text-gray-400 mb-2">
              No documents yet
            </Typography>
            <Typography variant="body2" className="text-gray-500 mb-4">
              Upload a PDF to get started
            </Typography>
            <Button
              variant="outlined"
              startIcon={<CloudUpload />}
              onClick={onUploadClick}
            >
              Upload Your First Document
            </Button>
          </Box>
        ) : (
          <Box className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documents.map((doc) => {
              const { hasMarkdown, hasVectorized, isReady } = getStatusIndicators(doc);
              // Check if this specific document is being vectorized
              const isVectorizing = vectorizeMutation.isPending && 
                vectorizeMutation.variables === doc.document_id;
              
              const handleVectorizeClick = (e: React.MouseEvent) => {
                e.stopPropagation(); // Prevent card click
                vectorizeMutation.mutate(doc.document_id);
              };
              
              return (
                <Card
                  key={doc.document_id}
                  className="cursor-pointer hover:shadow-lg transition-all duration-200 border border-gray-700 hover:border-blue-500 bg-[#2a2a2a]"
                  onClick={() => onSelectDocument(doc.document_id)}
                >
                  <CardContent className="p-4">
                    <Box className="flex items-start justify-between mb-3">
                      <Box className="flex-1 min-w-0">
                        <Typography
                          variant="h6"
                          className="font-medium truncate mb-1 text-gray-100"
                          title={doc.name}
                        >
                          {doc.name}
                        </Typography>
                        <Box className="flex items-center gap-3 text-sm text-gray-400">
                          {doc.total_pages && (
                            <span>{doc.total_pages} pages</span>
                          )}
                          {doc.total_chunks && (
                            <span>{doc.total_chunks} chunks</span>
                          )}
                        </Box>
                      </Box>
                    </Box>

                    {/* Status Indicators */}
                    <Box className="flex items-center gap-3 mt-3 pt-3 border-t border-gray-700">
                      <Box className="flex items-center gap-1">
                        {hasMarkdown ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <Box className="w-4 h-4 border-2 border-gray-600 rounded-full" />
                        )}
                        <Typography variant="caption" className="text-xs text-gray-400">
                          Markdown
                        </Typography>
                      </Box>
                      <Box className="flex items-center gap-1">
                        {hasVectorized ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <Box className="w-4 h-4 border-2 border-gray-600 rounded-full" />
                        )}
                        <Typography variant="caption" className="text-xs text-gray-400">
                          Vectorized
                        </Typography>
                      </Box>
                      <Box className="flex items-center gap-1">
                        {isReady ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <Box className="w-4 h-4 border-2 border-gray-600 rounded-full" />
                        )}
                        <Typography variant="caption" className="text-xs text-gray-400">
                          Ready
                        </Typography>
                      </Box>
                    </Box>
                    
                    {/* Action Buttons */}
                    {hasMarkdown && !hasVectorized && (
                      <Box className="mt-3 pt-3 border-t border-gray-700">
                        <Button
                          variant="contained"
                          size="small"
                          fullWidth
                          onClick={handleVectorizeClick}
                          disabled={isVectorizing}
                          startIcon={
                            isVectorizing ? (
                              <CircularProgress size={14} color="inherit" />
                            ) : (
                              <Sparkles className="w-4 h-4" />
                            )
                          }
                          className={isVectorizing 
                            ? "bg-gray-600 text-gray-400 cursor-not-allowed" 
                            : "bg-blue-600 hover:bg-blue-700 text-white"
                          }
                          sx={{
                            '&.Mui-disabled': {
                              backgroundColor: '#4b5563',
                              color: '#9ca3af',
                              cursor: 'not-allowed',
                            },
                            '&:hover.Mui-disabled': {
                              backgroundColor: '#4b5563',
                            }
                          }}
                        >
                          {isVectorizing ? 'Vectorizing...' : 'Vectorize'}
                        </Button>
                      </Box>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </Box>
        )}
      </Box>

      {/* Hidden file input for upload */}
      <input
        type="file"
        accept=".pdf"
        onChange={handleFileInput}
        className="hidden"
        id="file-upload-input"
      />
    </Box>
  );
};
