import { useState, useEffect } from 'react';
import { useDocument, useVectorizeDocument } from '../hooks/useDocuments';
import { useDocumentQuery } from '../hooks/useQuery';
import { QueryInterface } from './QueryInterface';
import { QueryResults } from './QueryResults';
import { MarkdownViewer } from './MarkdownViewer';
import { GraphVisualization } from './GraphVisualization';
import { PageNavigator } from './PageNavigator';
import { Box, Tabs, Tab, Typography, Alert } from '@mui/material';
import { FileText as FileTextIcon, Search, Network, BookOpen } from 'lucide-react';
import type { QueryResponse, ChunkDetail } from '../api/types';

interface DocumentViewerProps {
  documentId: string;
}

export const DocumentViewer = ({ documentId }: DocumentViewerProps) => {
  const [activeTab, setActiveTab] = useState(0);
  const [queryResults, setQueryResults] = useState<QueryResponse | null>(null);
  const [selectedChunk, setSelectedChunk] = useState<ChunkDetail | null>(null);

  const { data: document, isLoading } = useDocument(documentId);
  const vectorizeMutation = useVectorizeDocument();
  const queryMutation = useDocumentQuery();

  // Auto-vectorize when document is processed
  useEffect(() => {
    if (document?.status === 'processing' && document.markdown_path) {
      // Wait a bit then check if vectorized
      const timer = setTimeout(() => {
        if (document.status === 'processing') {
          vectorizeMutation.mutate(documentId);
        }
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [document?.status, documentId, vectorizeMutation]);

  // Update query results when mutation succeeds
  useEffect(() => {
    if (queryMutation.isSuccess && queryMutation.data) {
      setQueryResults(queryMutation.data);
      setActiveTab(1); // Switch to results tab
    }
  }, [queryMutation.isSuccess, queryMutation.data]);

  const handleQuerySuccess = (query: string) => {
    // Results are set via useEffect above
  };

  const handleChunkSelect = (chunk: ChunkDetail) => {
    setSelectedChunk(chunk);
    setActiveTab(2); // Switch to markdown tab
  };

  if (isLoading) {
    return (
      <Box className="p-8">
        <Typography>Loading document...</Typography>
      </Box>
    );
  }

  if (!document) {
    return (
      <Box className="p-8">
        <Typography>Document not found</Typography>
      </Box>
    );
  }

  return (
    <Box className="h-full flex flex-col">
      {/* Header */}
      <Box className="p-4 border-b bg-white dark:bg-gray-800">
        <Typography variant="h5" className="mb-2">
          {document.name}
        </Typography>
        <Box className="flex items-center gap-4 text-sm text-gray-500">
          {document.total_pages && <span>{document.total_pages} pages</span>}
          {document.total_chunks && <span>{document.total_chunks} chunks</span>}
        </Box>
      </Box>

      {/* Tabs */}
      <Tabs
        value={activeTab}
        onChange={(_, newValue) => setActiveTab(newValue)}
        className="border-b"
      >
        <Tab icon={<Search className="w-5 h-5" />} label="Query" />
        <Tab icon={<FileTextIcon className="w-5 h-5" />} label="Results" />
        <Tab icon={<FileTextIcon className="w-5 h-5" />} label="Markdown" />
        <Tab icon={<Network className="w-5 h-5" />} label="Graph" />
        <Tab icon={<BookOpen className="w-5 h-5" />} label="Pages" />
      </Tabs>

      {/* Content */}
      <Box className="flex-1 overflow-auto p-6">
        {activeTab === 0 && (
          <Box className="max-w-4xl mx-auto space-y-6">
            <QueryInterface documentId={documentId} onQuerySuccess={handleQuerySuccess} />
            {document.status !== 'ready' && (
              <Alert severity="info">
                Document is {document.status}. Please wait until it&apos;s ready to query.
              </Alert>
            )}
          </Box>
        )}

        {activeTab === 1 && queryResults && (
          <Box className="max-w-6xl mx-auto">
            <QueryResults results={queryResults} onChunkSelect={handleChunkSelect} />
          </Box>
        )}

        {activeTab === 2 && (
          <Box className="h-full">
            <MarkdownViewer
              documentId={documentId}
              chunks={queryResults?.chunks || []}
              selectedChunkIndex={selectedChunk?.chunk_index}
            />
          </Box>
        )}

        {activeTab === 3 && (
          <Box className="h-full">
            <GraphVisualization documentId={documentId} />
          </Box>
        )}

        {activeTab === 4 && (
          <Box className="max-w-4xl mx-auto">
            <PageNavigator documentId={documentId} totalPages={document.total_pages || undefined} />
          </Box>
        )}
      </Box>
    </Box>
  );
};
