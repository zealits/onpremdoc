import { useState, useEffect, useRef } from 'react';
import { Box, Typography, TextField, Button, CircularProgress, Alert } from '@mui/material';
import { Send, Sparkles, FileText } from 'lucide-react';
import { useDocument, useVectorizeDocument } from '../hooks/useDocuments';
import { useDocumentQuery } from '../hooks/useQuery';
import { ChunkAnalysis } from './ChunkAnalysis';
import { renderAnswerWithChunkReferences } from '../utils/chunkParser';
import type { ChunkDetail, QueryResponse } from '../api/types';

interface ChatPanelProps {
  documentId: string;
  onChunkClick: (chunkIndex: number) => void;
  onChunksUpdate: (chunks: ChunkDetail[]) => void;
}

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  queryResponse?: QueryResponse;
}

export const ChatPanel = ({ documentId, onChunkClick, onChunksUpdate }: ChatPanelProps) => {
  const { data: document, isLoading: docLoading } = useDocument(documentId);
  const vectorizeMutation = useVectorizeDocument();
  const queryMutation = useDocumentQuery();
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const answerContainerRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Listen for chunk clicks from rendered answer
  useEffect(() => {
    const handleChunkClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.hasAttribute('data-chunk-link')) {
        e.preventDefault();
        const chunkIndex = parseInt(target.getAttribute('data-chunk-index') || '0', 10);
        if (chunkIndex > 0) {
          onChunkClick(chunkIndex);
        }
      }
    };

    const container = answerContainerRef.current;
    if (container) {
      container.addEventListener('click', handleChunkClick);
      return () => {
        container.removeEventListener('click', handleChunkClick);
      };
    }
  }, [onChunkClick]);

  const handleVectorize = async () => {
    try {
      await vectorizeMutation.mutateAsync(documentId);
    } catch (error) {
      console.error('Vectorization failed:', error);
    }
  };

  const handleQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || !documentId) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: query.trim(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setQuery('');

    try {
      const response = await queryMutation.mutateAsync({
        query: query.trim(),
        document_id: documentId,
        include_chunks: true,
      });

      // Update chunks for highlighting
      if (response.chunks) {
        onChunksUpdate(response.chunks);
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response.answer,
        queryResponse: response,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Query failed:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'Sorry, I encountered an error processing your query. Please try again.',
      };
      setMessages((prev) => [...prev, errorMessage]);
    }
  };

  if (docLoading) {
    return (
      <Box className="flex justify-center items-center h-full">
        <CircularProgress size={24} />
      </Box>
    );
  }

  // Check document status
  const hasMarkdown = document?.markdown_path !== null && document?.markdown_path !== undefined;
  const isVectorized = document?.vector_mapping_path !== null && document?.vector_mapping_path !== undefined;
  const isReady = document?.status === 'ready';
  const isVectorizing = vectorizeMutation.isPending;
  // Only show processing when markdown doesn't exist yet (not based on status)
  const isProcessingMarkdown = !hasMarkdown;

  // Show processing message (markdown conversion) - only when markdown doesn't exist
  if (isProcessingMarkdown) {
    return (
      <Box className="flex flex-col items-center justify-center h-full p-6 text-center bg-[#1a1a1a]">
        <FileText className="w-16 h-16 mb-4 text-gray-500 opacity-50" />
        <Typography variant="body1" className="mb-2 text-gray-300">
          Markdown conversion in progress
        </Typography>
        <Typography variant="body2" className="text-gray-500">
          Please wait while the PDF is being converted to markdown...
        </Typography>
      </Box>
    );
  }

  // Show vectorization in progress
  if (isVectorizing) {
    return (
      <Box className="flex flex-col items-center justify-center h-full p-6 text-center bg-[#1a1a1a]">
        <CircularProgress size={40} className="mb-4" />
        <Typography variant="h6" className="mb-2 text-gray-100">
          Vectorizing Document
        </Typography>
        <Typography variant="body2" className="text-gray-400">
          Creating embeddings and knowledge graph...
        </Typography>
      </Box>
    );
  }

  // Show vectorization prompt (markdown ready, but not vectorized)
  // Only show button if not currently vectorizing (button disappears when vectorization starts)
  if (!isVectorized && !isReady && !isVectorizing) {
    return (
      <Box className="flex flex-col items-center justify-center h-full p-6 text-center bg-[#1a1a1a]">
        <Sparkles className="w-16 h-16 text-blue-400 mb-4" />
        <Typography variant="h6" className="mb-2 text-gray-100">
          Vectorize Document
        </Typography>
        <Typography variant="body2" className="text-gray-400 mb-6 max-w-md">
          To enable chat and querying, please vectorize this document first. This will create
          embeddings and a knowledge graph.
        </Typography>
        <Button
          variant="contained"
          onClick={handleVectorize}
          startIcon={<Sparkles className="w-5 h-5" />}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          Vectorize
        </Button>
        {vectorizeMutation.isError && (
          <Alert severity="error" className="mt-4">
            Vectorization failed. Please try again.
          </Alert>
        )}
      </Box>
    );
  }

  // Show chat interface
  return (
    <Box className="h-full flex flex-col bg-[#1a1a1a]">
      {/* Messages Area */}
      <Box className="flex-1 overflow-auto p-4 space-y-4">
        {messages.length === 0 && (
          <Box className="text-center py-8 text-gray-400">
            <Typography variant="body1" className="mb-2 text-gray-300">
              Start a conversation
            </Typography>
            <Typography variant="body2" className="text-gray-500">
              Ask questions about the document
            </Typography>
          </Box>
        )}

        {messages.map((message) => (
          <Box
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <Box
              className={`max-w-[80%] rounded-lg p-4 ${message.type === 'user'
                ? 'bg-blue-600 text-white'
                : 'bg-[#2a2a2a] text-gray-100'
                }`}
            >
              {message.type === 'user' ? (
                <Typography variant="body1">{message.content}</Typography>
              ) : (
                <Box>
                  <Box
                    ref={answerContainerRef}
                    className="prose prose-sm max-w-none"
                    dangerouslySetInnerHTML={{
                      __html: renderAnswerWithChunkReferences(message.content),
                    }}
                  />
                  {message.queryResponse && (
                    <ChunkAnalysis
                      chunkAnalysis={message.queryResponse.chunk_analysis || null}
                      chunks={message.queryResponse.chunks}
                      onChunkClick={onChunkClick}
                    />
                  )}
                </Box>
              )}
            </Box>
          </Box>
        ))}

        {queryMutation.isPending && (
          <Box className="flex justify-start">
            <Box className="bg-[#2a2a2a] rounded-lg p-4">
              <CircularProgress size={16} className="mr-2" />
              <Typography variant="body2" className="text-gray-300 inline">
                Thinking...
              </Typography>
            </Box>
          </Box>
        )}

        <div ref={messagesEndRef} />
      </Box>

      {/* Input Area */}
      <Box className="border-t border-gray-700 p-4 bg-[#1a1a1a]">
        <form onSubmit={handleQuery} className="flex gap-2">
          <TextField
            fullWidth
            placeholder="Ask a question about the document..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={queryMutation.isPending}
            variant="outlined"
            size="small"
            multiline
            maxRows={3}
          />
          <Button
            type="submit"
            variant="contained"
            disabled={!query.trim() || queryMutation.isPending}
            className="bg-blue-600 hover:bg-blue-700 min-w-[80px]"
            startIcon={
              queryMutation.isPending ? (
                <CircularProgress size={16} color="inherit" />
              ) : (
                <Send className="w-4 h-4" />
              )
            }
          >
            {queryMutation.isPending ? '...' : 'Send'}
          </Button>
        </form>
        <Typography variant="caption" className="text-gray-400 mt-2 block text-xs">
          NotebookLM can be inaccurate; please double check its responses.
        </Typography>
      </Box>
    </Box>
  );
};
