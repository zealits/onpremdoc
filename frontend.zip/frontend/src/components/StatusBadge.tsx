import { Chip } from '@mui/material';
import { CheckCircle, HourglassEmpty, CloudUpload, CheckCircleOutline } from '@mui/icons-material';

interface StatusBadgeProps {
  status: 'uploaded' | 'processing' | 'vectorized' | 'ready';
}

export const StatusBadge = ({ status }: StatusBadgeProps) => {
  const getStatusConfig = () => {
    switch (status) {
      case 'uploaded':
        return {
          label: 'Uploaded',
          color: 'default' as const,
          icon: <CloudUpload />,
        };
      case 'processing':
        return {
          label: 'Processing',
          color: 'warning' as const,
          icon: <HourglassEmpty />,
        };
      case 'vectorized':
        return {
          label: 'Vectorized',
          color: 'info' as const,
          icon: <CheckCircleOutline />,
        };
      case 'ready':
        return {
          label: 'Ready',
          color: 'success' as const,
          icon: <CheckCircle />,
        };
      default:
        return {
          label: status,
          color: 'default' as const,
          icon: null,
        };
    }
  };

  const config = getStatusConfig();

  return (
    <Chip
      icon={config.icon}
      label={config.label}
      color={config.color}
      size="small"
    />
  );
};
