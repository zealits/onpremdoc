import { useEffect, useRef, useState } from 'react';
import { Box, CircularProgress, Typography } from '@mui/material';
import { useMarkdown, useDocument } from '../hooks/useDocuments';
import { scrollToChunk, highlightChunkInDom, configureMarked } from '../utils/markdown';
import type { ChunkDetail } from '../api/types';

interface SourcesPanelProps {
  documentId: string;
  chunks: ChunkDetail[];
  selectedChunkIndex?: number | null;
}

export const SourcesPanel = ({ documentId, chunks, selectedChunkIndex }: SourcesPanelProps) => {
  const { data: markdown, isLoading, refetch: refetchMarkdown } = useMarkdown(documentId);
  const { data: document } = useDocument(documentId);
  const viewerRef = useRef<HTMLDivElement>(null);
  const [highlightedHtml, setHighlightedHtml] = useState<string>('');

  // Configure marked on mount
  useEffect(() => {
    configureMarked();
  }, []);

  // Refetch markdown when markdown_path becomes available
  useEffect(() => {
    if (document?.markdown_path && !markdown && !isLoading) {
      // Markdown path exists but we don't have the content yet, try to fetch it
      refetchMarkdown();
    }
  }, [document?.markdown_path, markdown, isLoading, refetchMarkdown]);

  // Render markdown - plain markdown, no pre-highlighting
  useEffect(() => {
    const renderMarkdown = async () => {
      if (!markdown) return;

      try {
        const { marked } = await import('marked');
        // Configure marked options
        marked.setOptions({
          breaks: true,
          gfm: true,
          headerIds: true,
          mangle: false,
        });
        
        // Always render plain markdown (no highlights)
        const html = await marked.parse(markdown);
        setHighlightedHtml(html);
      } catch (err) {
        console.error('Error parsing markdown:', err);
        setHighlightedHtml('<p class="text-red-400">Error rendering markdown. Please refresh the page.</p>');
      }
    };

    renderMarkdown();
  }, [markdown]);

  // Scroll to selected chunk and highlight it
  useEffect(() => {
    if (selectedChunkIndex !== null && selectedChunkIndex !== undefined && viewerRef.current && chunks.length > 0) {
      // Remove any existing highlights first
      const existingHighlights = viewerRef.current.querySelectorAll('.chunk-highlight');
      existingHighlights.forEach((el) => {
        el.classList.remove('chunk-highlight', 'chunk-highlight-active');
        el.removeAttribute('data-chunk-index');
        const id = el.id;
        if (id && id.startsWith('chunk-')) {
          el.removeAttribute('id');
        }
      });

      // Small delay to ensure HTML is rendered, then highlight and scroll
      setTimeout(() => {
        const chunk = chunks.find(c => c.chunk_index === selectedChunkIndex);
        if (chunk && viewerRef.current) {
          // Highlight the chunk in the DOM (pass raw markdown for accurate line matching)
          highlightChunkInDom(viewerRef.current, chunk, markdown || undefined);
          // Scroll to it (pass raw markdown)
          scrollToChunk(selectedChunkIndex, viewerRef.current, chunks, markdown || undefined);
        }
      }, 150);
    } else if (selectedChunkIndex === null && viewerRef.current) {
      // Remove all highlights when no chunk is selected
      const existingHighlights = viewerRef.current.querySelectorAll('.chunk-highlight');
      existingHighlights.forEach((el) => {
        el.classList.remove('chunk-highlight', 'chunk-highlight-active');
        el.removeAttribute('data-chunk-index');
        const id = el.id;
        if (id && id.startsWith('chunk-')) {
          el.removeAttribute('id');
        }
      });
    }
  }, [selectedChunkIndex, chunks]);

  // Listen for chunk-click events from chat panel
  useEffect(() => {
    const handleChunkClick = (event: CustomEvent<{ chunkIndex: number }>) => {
      if (viewerRef.current) {
        setTimeout(() => {
          scrollToChunk(event.detail.chunkIndex, viewerRef.current, chunks, markdown || undefined);
        }, 100);
      }
    };

    const handleHighlightChunk = (event: CustomEvent<{ chunkIndex: number; chunk: ChunkDetail }>) => {
      // Highlight chunk in DOM
      if (viewerRef.current && event.detail.chunk) {
        // Remove existing highlights
        const existingHighlights = viewerRef.current.querySelectorAll('.chunk-highlight');
        existingHighlights.forEach((el) => {
          el.classList.remove('chunk-highlight', 'chunk-highlight-active');
          el.removeAttribute('data-chunk-index');
          const id = el.id;
          if (id && id.startsWith('chunk-')) {
            el.removeAttribute('id');
          }
        });
        
        // Add new highlight (pass raw markdown for accurate line matching)
        highlightChunkInDom(viewerRef.current, event.detail.chunk, markdown || undefined);
        setTimeout(() => {
          scrollToChunk(event.detail.chunkIndex, viewerRef.current, chunks, markdown || undefined);
        }, 50);
      }
    };

    window.addEventListener('chunk-click', handleChunkClick as EventListener);
    window.addEventListener('highlight-chunk', handleHighlightChunk as EventListener);
    return () => {
      window.removeEventListener('chunk-click', handleChunkClick as EventListener);
      window.removeEventListener('highlight-chunk', handleHighlightChunk as EventListener);
    };
  }, [chunks, markdown]);

  // Show processing message only when markdown doesn't exist yet
  // Once markdown exists, show it regardless of status
  const isProcessing = !markdown && (document?.status === 'processing' || isLoading);
  
  if (isProcessing) {
    return (
      <Box className="flex flex-col justify-center items-center h-full bg-[#1a1a1a]">
        <CircularProgress size={40} className="mb-4" />
        <Typography variant="h6" className="mb-2 text-gray-100">
          Processing Document
        </Typography>
        <Typography variant="body2" className="text-gray-400">
          Converting PDF to markdown...
        </Typography>
      </Box>
    );
  }

  if (!markdown) {
    return (
      <Box className="p-4 text-gray-400 text-center bg-[#1a1a1a]">
        <Typography variant="body2">Markdown content not available</Typography>
      </Box>
    );
  }

  return (
    <Box className="h-full overflow-auto bg-[#1a1a1a]" ref={viewerRef}>
      <Box
        className="prose prose-sm max-w-none p-6"
        dangerouslySetInnerHTML={{ __html: highlightedHtml }}
      />
    </Box>
  );
};
