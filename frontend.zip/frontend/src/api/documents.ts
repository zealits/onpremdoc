import { apiClient } from './client';
import type {
  DocumentInfo,
  PageSummaryResponse,
  GraphStats,
  ProcessPDFResponse,
  VectorizeResponse,
} from './types';

export const documentsApi = {
  // List all documents
  listDocuments: async (): Promise<DocumentInfo[]> => {
    const response = await apiClient.get<DocumentInfo[]>('/documents');
    return response.data;
  },

  // Get single document
  getDocument: async (documentId: string): Promise<DocumentInfo> => {
    const response = await apiClient.get<DocumentInfo>(`/documents/${documentId}`);
    return response.data;
  },

  // Upload PDF
  uploadPDF: async (file: File): Promise<ProcessPDFResponse> => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await apiClient.post<ProcessPDFResponse>('/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },


  // Vectorize document
  vectorizeDocument: async (documentId: string): Promise<VectorizeResponse> => {
    const response = await apiClient.post<VectorizeResponse>(`/vectorize/${documentId}`);
    return response.data;
  },

  // Get markdown content (NOTE: You'll need to add this endpoint to the API)
  getMarkdown: async (documentId: string): Promise<string> => {
    const response = await apiClient.get(`/documents/${documentId}/markdown`, {
      responseType: 'text',
    });
    return response.data;
  },

  // Get page summary
  getPageSummary: async (documentId: string, pageNumber: number): Promise<PageSummaryResponse> => {
    const response = await apiClient.post<PageSummaryResponse>(
      `/page/${documentId}/summarize?page_number=${pageNumber}`
    );
    return response.data;
  },

  // Get graph stats
  getGraphStats: async (documentId: string): Promise<GraphStats> => {
    const response = await apiClient.get<GraphStats>(`/visualize/${documentId}/stats`);
    return response.data;
  },

  // Get graph visualization (returns HTML blob)
  getGraphVisualization: async (
    documentId: string,
    vizType: 'interactive' | 'static' | 'simplified' = 'interactive'
  ): Promise<Blob> => {
    const response = await apiClient.post(
      `/visualize/${documentId}?viz_type=${vizType}`,
      {},
      {
        responseType: 'blob',
      }
    );
    return response.data;
  },
};
