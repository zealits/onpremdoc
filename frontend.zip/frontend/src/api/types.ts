export interface DocumentInfo {
  document_id: string;
  name: string;
  status: 'uploaded' | 'processing' | 'vectorized' | 'ready';
  markdown_path?: string | null;
  page_mapping_path?: string | null;
  vector_mapping_path?: string | null;
  graph_path?: string | null;
  vector_db_path?: string | null;
  total_pages?: number | null;
  total_chunks?: number | null;
}

export interface ChunkDetail {
  chunk_index: number;
  content: string;
  heading: string;
  section_path: string;
  section_title: string;
  page_number?: number | null;
  page_classification?: string | null;
  summary: string;
  chunk_type: string;
  has_table: boolean;
  table_context?: string | null;
  start_line?: number | null;
  content_length: number;
  retrieval_source: 'seed' | 'graph_expanded' | 'second_seed' | 'second_expanded' | 'initial' | 'second_retrieval';
  similarity_score?: number | null;
}

export interface QueryRequest {
  query: string;
  document_id: string;
  include_chunks?: boolean;
}

export interface QueryResponse {
  answer: string;
  document_id: string;
  query: string;
  retrieval_stats: {
    seed_chunks: number;
    graph_expanded_chunks: number;
    total_initial_chunks: number;
    second_seed_chunks: number;
    second_expanded_chunks: number;
    total_second_chunks: number;
    total_chunks_used: number;
    iterations: number;
    second_query?: string;
  };
  chunk_analysis?: string | null;
  chunks: ChunkDetail[];
}

export interface PageSummaryResponse {
  page_number: number;
  summary: string;
  key_points: string[];
  sections: string[];
  has_content: boolean;
  used_adjacent_pages: boolean;
  adjacent_pages_used?: number[] | null;
  page_classification?: string | null;
  chunks_used: number[];
  total_chunks: number;
}

export interface HealthResponse {
  status: string;
  ollama_available: boolean;
  ollama_models: string[];
}

export interface GraphStats {
  total_nodes: number;
  total_edges: number;
  node_types: Record<string, number>;
  edge_relations: Record<string, number>;
  density: number;
  similarity_stats?: {
    count: number;
    average: number;
    min: number;
    max: number;
  };
}

export interface ProcessPDFResponse {
  document_id: string;
  status: string;
  message: string;
  markdown_path?: string | null;
  page_mapping_path?: string | null;
  total_pages?: number | null;
}

export interface VectorizeResponse {
  document_id: string;
  status: string;
  message: string;
  vector_mapping_path?: string | null;
  graph_path?: string | null;
  vector_db_path?: string | null;
  total_chunks?: number | null;
  graph_nodes?: number | null;
  graph_edges?: number | null;
}
