import { apiClient } from './client';
import type { QueryRequest, QueryResponse } from './types';

export const queriesApi = {
  query: async (request: QueryRequest): Promise<QueryResponse> => {
    const response = await apiClient.post<QueryResponse>('/query', request);
    return response.data;
  },
};
