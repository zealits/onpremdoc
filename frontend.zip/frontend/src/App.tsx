import { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import { HomePage } from './components/HomePage';
import { DocumentWorkspace } from './components/DocumentWorkspace';
import { DocumentUpload } from './components/DocumentUpload';
import { Box, Dialog, DialogContent } from '@mui/material';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#60a5fa',
    },
    background: {
      default: '#1a1a1a',
      paper: '#2a2a2a',
    },
    text: {
      primary: '#e5e5e5',
      secondary: '#a3a3a3',
    },
  },
});

function App() {
  const [selectedDocumentId, setSelectedDocumentId] = useState<string | null>(null);
  const [showUpload, setShowUpload] = useState(false);

  const handleSelectDocument = (documentId: string) => {
    setSelectedDocumentId(documentId);
  };

  const handleBack = () => {
    setSelectedDocumentId(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box className="h-screen w-screen overflow-hidden">
          {selectedDocumentId ? (
            <DocumentWorkspace documentId={selectedDocumentId} onBack={handleBack} />
          ) : (
            <HomePage
              onSelectDocument={handleSelectDocument}
              onUploadClick={() => setShowUpload(true)}
            />
          )}

          {/* Upload Dialog */}
          <Dialog
            open={showUpload}
            onClose={() => setShowUpload(false)}
            maxWidth="md"
            fullWidth
          >
            <DialogContent>
              <DocumentUpload />
              <Box className="mt-4 text-center">
                <button
                  onClick={() => setShowUpload(false)}
                  className="text-blue-400 hover:text-blue-300 hover:underline text-sm"
                >
                  Close
                </button>
              </Box>
            </DialogContent>
          </Dialog>
        </Box>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
