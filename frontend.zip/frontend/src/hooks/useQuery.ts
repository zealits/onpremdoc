import { useMutation } from '@tanstack/react-query';
import { queriesApi } from '../api/queries';
import type { QueryRequest } from '../api/types';

export const useDocumentQuery = () => {
  return useMutation({
    mutationFn: queriesApi.query,
  });
};
