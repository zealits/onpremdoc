import { useEffect, useRef } from 'react';

export const usePolling = <T>(
  callback: () => Promise<T>,
  condition: (data: T) => boolean,
  interval: number = 2000
) => {
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const poll = async () => {
      const data = await callback();
      if (!condition(data)) {
        intervalRef.current = setTimeout(poll, interval);
      }
    };

    poll();

    return () => {
      if (intervalRef.current) {
        clearTimeout(intervalRef.current);
      }
    };
  }, [callback, condition, interval]);
};
