import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { documentsApi } from '../api/documents';
import type { DocumentInfo } from '../api/types';

export const useDocuments = () => {
  return useQuery({
    queryKey: ['documents'],
    queryFn: documentsApi.listDocuments,
    refetchInterval: 5000, // Poll every 5 seconds
  });
};

export const useDocument = (documentId: string | null) => {
  return useQuery({
    queryKey: ['document', documentId],
    queryFn: () => documentsApi.getDocument(documentId!),
    enabled: !!documentId,
    refetchInterval: (query) => {
      const data = query.state.data as DocumentInfo | undefined;
      // Poll more frequently if processing
      if (data?.status === 'processing' || data?.status === 'vectorized') {
        return 2000; // 2 seconds
      }
      return false; // Don't poll if ready
    },
  });
};

export const useUploadDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: documentsApi.uploadPDF,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
    },
  });
};


export const useVectorizeDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: documentsApi.vectorizeDocument,
    onSuccess: (_, documentId) => {
      queryClient.invalidateQueries({ queryKey: ['document', documentId] });
      queryClient.invalidateQueries({ queryKey: ['documents'] });
    },
  });
};

export const useMarkdown = (documentId: string | null) => {
  const queryClient = useQueryClient();
  
  return useQuery({
    queryKey: ['markdown', documentId],
    queryFn: () => documentsApi.getMarkdown(documentId!),
    enabled: !!documentId,
    staleTime: Infinity, // Markdown doesn't change once created
    retry: (failureCount, error: any) => {
      // Retry if 404 (markdown not ready yet), but stop after 3 failures
      if (error?.response?.status === 404 && failureCount < 3) {
        return true;
      }
      return false;
    },
    refetchInterval: (query) => {
      // Poll for markdown if document is processing and we don't have markdown yet
      if (!query.state.data) {
        const documentQuery = queryClient.getQueryState(['document', documentId]);
        const document = documentQuery?.data as DocumentInfo | undefined;
        if (document?.status === 'processing' || document?.status === 'uploaded') {
          return 2000; // Poll every 2 seconds
        }
      }
      return false; // Don't poll once we have markdown
    },
  });
};

export const usePageSummary = (documentId: string | null, pageNumber: number | null) => {
  return useQuery({
    queryKey: ['pageSummary', documentId, pageNumber],
    queryFn: () => documentsApi.getPageSummary(documentId!, pageNumber!),
    enabled: !!documentId && !!pageNumber,
  });
};

export const useGraphStats = (documentId: string | null) => {
  return useQuery({
    queryKey: ['graphStats', documentId],
    queryFn: () => documentsApi.getGraphStats(documentId!),
    enabled: !!documentId,
    staleTime: 60000, // Consider data fresh for 60 seconds
    refetchOnWindowFocus: false, // Don't refetch on window focus
    refetchOnMount: false, // Don't refetch on mount if data exists
  });
};
