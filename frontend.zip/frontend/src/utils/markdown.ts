import { marked } from 'marked';
import type { ChunkDetail as ChunkDetailType } from '../api/types';

/**
 * Configure marked with proper options for markdown rendering
 */
export const configureMarked = () => {
  marked.setOptions({
    breaks: true, // Convert line breaks to <br>
    gfm: true, // GitHub Flavored Markdown
    headerIds: true, // Add IDs to headers
    mangle: false, // Don't mangle email addresses
  });
};

/**
 * Normalize text for comparison (remove extra whitespace, normalize line breaks)
 */
const normalizeText = (text: string): string => {
  return text
    .replace(/\s+/g, ' ') // Replace all whitespace with single space
    .replace(/\n+/g, ' ') // Replace line breaks with space
    .trim()
    .toLowerCase();
};

/**
 * Extract a searchable substring from chunk content (first 100-200 chars)
 */
const getSearchText = (content: string): string => {
  // Take first meaningful portion of content (skip very short chunks)
  const minLength = 50;
  const maxLength = 300;
  
  if (content.length < minLength) {
    return normalizeText(content);
  }
  
  // Try to get a complete sentence or paragraph
  const substring = content.substring(0, Math.min(maxLength, content.length));
  // Try to end at a sentence boundary if possible
  const lastPeriod = substring.lastIndexOf('.');
  const lastNewline = substring.lastIndexOf('\n');
  const endIndex = Math.max(lastPeriod, lastNewline, minLength);
  
  return normalizeText(content.substring(0, endIndex));
};

/**
 * Find text in DOM element and its children
 * Returns a score (0-1) indicating how well the text matches
 */
const findTextInElement = (element: HTMLElement, searchText: string): number => {
  const elementText = normalizeText(element.textContent || '');
  if (!elementText || elementText.length < searchText.length / 2) {
    return 0;
  }
  
  // Check if search text is contained in element text
  if (elementText.includes(searchText)) {
    return 1.0; // Perfect match
  }
  
  // Check for partial matches (at least 70% of search text)
  const minMatchLength = Math.floor(searchText.length * 0.7);
  for (let i = 0; i <= searchText.length - minMatchLength; i++) {
    const substring = searchText.substring(i, i + minMatchLength);
    if (elementText.includes(substring)) {
      return 0.7; // Good partial match
    }
  }
  
  // Check if element text is contained in search text (element is part of chunk)
  if (searchText.includes(elementText) && elementText.length > 20) {
    return 0.5; // Element is part of the chunk
  }
  
  return 0;
};

/**
 * Calculate the number of lines a chunk spans based on content length
 * Uses a more accurate estimation: average line length in markdown is ~80-100 chars
 */
const calculateChunkLines = (contentLength: number, startLine?: number | null): number => {
  // Estimate lines based on content length
  // Average markdown line is ~80-100 characters, but can vary
  const avgCharsPerLine = 85;
  const estimatedLines = Math.ceil(contentLength / avgCharsPerLine);
  
  // Ensure at least 1 line, and cap at reasonable maximum
  return Math.max(1, Math.min(estimatedLines, 50));
};

/**
 * Highlight a chunk in the rendered HTML using line numbers from raw markdown
 * Extracts content from raw markdown at the specified line range, then finds it in rendered HTML
 */
export const highlightChunkInDom = (
  container: HTMLElement,
  chunk: ChunkDetailType,
  rawMarkdown?: string // Pass the raw markdown text
): HTMLElement | null => {
  if (!container || !chunk.start_line) return null;

  // Calculate how many lines this chunk spans
  const startLine = chunk.start_line;
  const numLines = calculateChunkLines(chunk.content_length, startLine);
  const endLine = startLine + numLines - 1;

  // If we have raw markdown, extract the content at those line numbers
  let searchText: string | null = null;
  
  if (rawMarkdown) {
    const markdownLines = rawMarkdown.split('\n');
    // Extract lines from startLine to endLine (1-indexed to 0-indexed)
    const extractedLines = markdownLines.slice(startLine - 1, endLine);
    searchText = extractedLines.join('\n').trim();
    
    // Normalize for search (remove extra whitespace)
    searchText = normalizeText(searchText);
  }

  // Get all text-containing elements
  const allElements = Array.from(container.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, pre, code, blockquote, div'));
  
  const elementsToHighlight: HTMLElement[] = [];
  
  if (searchText && searchText.length > 10) {
    // Use the extracted text from raw markdown to find matching elements in HTML
    for (const el of allElements) {
      const element = el as HTMLElement;
      
      // Skip if already highlighted for a different chunk
      if (element.classList.contains('chunk-highlight') && 
          element.getAttribute('data-chunk-index') !== chunk.chunk_index.toString()) {
        continue;
      }
      
      const elementText = normalizeText(element.textContent || '');
      
      // Check if this element contains the search text (or a significant portion)
      if (elementText.includes(searchText) || searchText.includes(elementText)) {
        elementsToHighlight.push(element);
      }
    }
    
    // If we found matches, also include adjacent elements that might be part of the chunk
    if (elementsToHighlight.length > 0) {
      const firstIndex = allElements.indexOf(elementsToHighlight[0]);
      const lastIndex = allElements.indexOf(elementsToHighlight[elementsToHighlight.length - 1]);
      
      // Include a few elements before and after
      for (let i = Math.max(0, firstIndex - 1); i < Math.min(allElements.length, lastIndex + 2); i++) {
        if (!elementsToHighlight.includes(allElements[i] as HTMLElement)) {
          elementsToHighlight.push(allElements[i] as HTMLElement);
        }
      }
    }
  }
  
  // Fallback: if no matches found or no raw markdown, use approximate position
  if (elementsToHighlight.length === 0) {
    const allElementsFallback = Array.from(container.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, pre, code, blockquote, div.prose > *'));
    const approximateIndex = startLine - 1;
    if (approximateIndex >= 0 && approximateIndex < allElementsFallback.length) {
      const startIndex = Math.max(0, approximateIndex - 1);
      const endIndex = Math.min(allElementsFallback.length, approximateIndex + numLines + 1);
      
      for (let i = startIndex; i < endIndex; i++) {
        const element = allElementsFallback[i] as HTMLElement;
        if (!element.classList.contains('chunk-highlight') || 
            element.getAttribute('data-chunk-index') === chunk.chunk_index.toString()) {
          elementsToHighlight.push(element);
        }
      }
    }
  }

  if (elementsToHighlight.length === 0) return null;

  // Highlight the found elements
  const firstHighlighted = elementsToHighlight[0];
  
  elementsToHighlight.forEach((el) => {
    if (!el.classList.contains('chunk-highlight')) {
      el.classList.add('chunk-highlight');
      el.setAttribute('data-chunk-index', chunk.chunk_index.toString());
      el.id = `chunk-${chunk.chunk_index}`;
    } else {
      // Update attributes if already highlighted
      el.setAttribute('data-chunk-index', chunk.chunk_index.toString());
      el.id = `chunk-${chunk.chunk_index}`;
    }
  });

  return firstHighlighted;
};

/**
 * Scroll to a specific chunk in the markdown viewer and highlight it smoothly
 */
export const scrollToChunk = (
  chunkIndex: number,
  containerRef: HTMLElement | null,
  chunks: ChunkDetailType[] = [],
  rawMarkdown?: string // Pass the raw markdown text
) => {
  if (!containerRef) return;

  const chunk = chunks.find(c => c.chunk_index === chunkIndex);
  if (!chunk || !chunk.start_line) return;

  // First, try to find existing highlighted element
  let chunkElement = containerRef.querySelector(`[data-chunk-index="${chunkIndex}"]`) as HTMLElement;
  
  if (!chunkElement) {
    // If not found, highlight it dynamically in the DOM (pass raw markdown)
    chunkElement = highlightChunkInDom(containerRef, chunk, rawMarkdown);
  }
  
  if (!chunkElement) {
    // Fallback: scroll to approximate position
    const estimatedScrollPosition = (chunk.start_line - 1) * 25; // Rough estimate: 25px per line
    containerRef.scrollTo({
      top: Math.max(0, estimatedScrollPosition - 200),
      behavior: 'smooth'
    });
    return;
  }

  // Smooth scroll to element
  chunkElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  
  // Add smooth highlight animation
  chunkElement.classList.add('chunk-highlight-active');
  
  // Remove active class after animation, but keep the highlight
  setTimeout(() => {
    chunkElement?.classList.remove('chunk-highlight-active');
  }, 3000);
};
