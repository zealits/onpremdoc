import type { ChunkDetail } from '../api/types';

export interface HighlightRange {
  startLine: number;
  endLine: number;
  chunkIndex: number;
  retrievalSource: ChunkDetail['retrieval_source'];
  similarityScore?: number | null;
}

export const calculateHighlightRanges = (chunks: ChunkDetail[]): HighlightRange[] => {
  return chunks
    .filter((chunk) => chunk.start_line !== null && chunk.start_line !== undefined)
    .map((chunk) => {
      // Estimate end line based on content length (rough estimate: ~80 chars per line)
      const estimatedLines = Math.ceil(chunk.content_length / 80);
      return {
        startLine: chunk.start_line!,
        endLine: chunk.start_line! + estimatedLines,
        chunkIndex: chunk.chunk_index,
        retrievalSource: chunk.retrieval_source,
        similarityScore: chunk.similarity_score,
      };
    })
    .sort((a, b) => a.startLine - b.startLine);
};

export const getHighlightColor = (
  retrievalSource: ChunkDetail['retrieval_source'],
  similarityScore?: number | null
): string => {
  switch (retrievalSource) {
    case 'seed':
      // High similarity - bright yellow
      return similarityScore && similarityScore > 0.7
        ? 'bg-yellow-300 dark:bg-yellow-600'
        : 'bg-yellow-200 dark:bg-yellow-700';
    case 'graph_expanded':
      // Medium - blue
      return 'bg-blue-200 dark:bg-blue-700';
    case 'second_seed':
      // Second search - green
      return 'bg-green-200 dark:bg-green-700';
    case 'second_expanded':
      // Second expanded - light green
      return 'bg-green-100 dark:bg-green-800';
    default:
      return 'bg-gray-200 dark:bg-gray-700';
  }
};

export const getHighlightOpacity = (similarityScore?: number | null): number => {
  if (!similarityScore) return 0.3;
  // Higher similarity = higher opacity
  return Math.min(0.7, 0.3 + similarityScore * 0.4);
};

/**
 * Find a chunk by chunk_index in the chunks array
 */
export const findChunkByIndex = (
  chunks: ChunkDetail[],
  chunkIndex: number
): ChunkDetail | undefined => {
  return chunks.find((chunk) => chunk.chunk_index === chunkIndex);
};

/**
 * Get the highlight range for a specific chunk index
 */
export const getHighlightRangeForChunk = (
  chunks: ChunkDetail[],
  chunkIndex: number
): HighlightRange | null => {
  const chunk = findChunkByIndex(chunks, chunkIndex);
  if (!chunk || chunk.start_line === null || chunk.start_line === undefined) {
    return null;
  }

  const estimatedLines = Math.ceil(chunk.content_length / 80);
  return {
    startLine: chunk.start_line,
    endLine: chunk.start_line + estimatedLines,
    chunkIndex: chunk.chunk_index,
    retrievalSource: chunk.retrieval_source,
    similarityScore: chunk.similarity_score,
  };
};