/**
 * Parse chunk references from answer text and make them clickable
 * Format: (Chunk X) where X is the chunk_index
 */

export interface ChunkReference {
  chunkIndex: number;
  startIndex: number;
  endIndex: number;
  originalText: string;
}

/**
 * Find all chunk references in text
 * Pattern: (Chunk X) where X is a number
 */
export const findChunkReferences = (text: string): ChunkReference[] => {
  const regex = /\(Chunk\s+(\d+)\)/g;
  const references: ChunkReference[] = [];
  let match;

  while ((match = regex.exec(text)) !== null) {
    references.push({
      chunkIndex: parseInt(match[1], 10),
      startIndex: match.index,
      endIndex: match.index + match[0].length,
      originalText: match[0],
    });
  }

  return references;
};

/**
 * Replace chunk references with clickable links
 */
export const replaceChunkReferences = (text: string): string => {
  const references = findChunkReferences(text);
  
  if (references.length === 0) {
    return text;
  }

  // Sort by start index in reverse order to replace from end to start
  // This prevents index shifting issues
  const sortedRefs = [...references].sort((a, b) => b.startIndex - a.startIndex);

  let result = text;
  
  sortedRefs.forEach((ref) => {
    const before = result.substring(0, ref.startIndex);
    const after = result.substring(ref.endIndex);
    const link = `<a href="#" class="chunk-reference text-blue-600 hover:text-blue-800 hover:underline cursor-pointer font-medium" data-chunk-index="${ref.chunkIndex}" data-chunk-link="true">${ref.originalText}</a>`;
    result = before + link + after;
  });

  return result;
};

/**
 * Parse markdown-style answer text and render with clickable chunk references
 */
export const renderAnswerWithChunkReferences = (answer: string): string => {
  // First, replace chunk references with clickable links
  let processed = replaceChunkReferences(answer);
  
  // Convert markdown-style formatting to HTML
  // Handle bold (**text**)
  processed = processed.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  
  // Handle line breaks
  processed = processed.replace(/\n/g, '<br/>');
  
  // Handle bullet points (* item)
  processed = processed.replace(/^\* (.+)$/gm, '<li>$1</li>');
  processed = processed.replace(/(<li>.*<\/li>\n?)+/g, (match) => {
    return '<ul class="list-disc list-inside my-2">' + match + '</ul>';
  });

  return processed;
};
